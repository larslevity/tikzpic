function [H,O] = evalConc(c)

H = 2*c(1)+c(3)+c(4)+2*c(6);
O = 2*c(2)+c(4)+c(5)+c(6);
